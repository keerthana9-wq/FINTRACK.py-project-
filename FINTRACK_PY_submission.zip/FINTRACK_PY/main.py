import json
from datetime import datetime
from pathlib import Path

DATA_FILE = Path("data.json")
CURRENCY = "₹"


class Transaction:
    def __init__(self, transaction_type, amount, category, date, description, payment_method):
        self.transaction_type = transaction_type
        self.amount = float(amount)
        self.category = category
        self.date = date
        self.description = description
        self.payment_method = payment_method

    def to_dict(self):
        return {
            "type": self.transaction_type,
            "amount": self.amount,
            "category": self.category,
            "date": self.date,
            "description": self.description,
            "payment_method": self.payment_method
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            data["type"], data["amount"], data["category"],
            data["date"], data["description"], data["payment_method"]
        )


class FinTrack:
    def __init__(self):
        self.transactions = []
        self.monthly_budget = 0.0
        self.load_data()

    def save_data(self):
        data = {
            "monthly_budget": self.monthly_budget,
            "transactions": [t.to_dict() for t in self.transactions]
        }
        with DATA_FILE.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def load_data(self):
        try:
            if DATA_FILE.exists():
                with DATA_FILE.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                self.monthly_budget = float(data.get("monthly_budget", 0))
                self.transactions = [
                    Transaction.from_dict(item) for item in data.get("transactions", [])
                ]
        except (json.JSONDecodeError, OSError, ValueError, KeyError):
            print("Warning: Could not load saved data. Starting with empty data.")

    @staticmethod
    def valid_date(value):
        try:
            datetime.strptime(value, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    def add_transaction(self):
        print("\n--- Add Transaction ---")
        while True:
            t_type = input("Type (income/expense): ").strip().lower()
            if t_type in ("income", "expense"):
                break
            print("Please enter income or expense.")

        while True:
            try:
                amount = float(input("Amount: ₹").strip())
                if amount > 0:
                    break
                print("Amount must be greater than 0.")
            except ValueError:
                print("Enter a valid number.")

        category = input("Category: ").strip().title() or "Other"

        while True:
            date = input("Date (YYYY-MM-DD): ").strip()
            if self.valid_date(date):
                break
            print("Use YYYY-MM-DD format.")

        description = input("Description: ").strip() or "No description"
        payment_method = input("Payment method: ").strip().title() or "Other"

        self.transactions.append(
            Transaction(t_type, amount, category, date, description, payment_method)
        )
        self.save_data()
        print("Transaction saved successfully.")

    def list_transactions(self, items=None):
        items = self.transactions if items is None else items
        print("\n--- Transaction List ---")
        if not items:
            print("No transactions found.")
            return
        print(f"{'No.':<5}{'Date':<13}{'Type':<10}{'Category':<16}{'Amount':>12}  Description")
        print("-" * 75)
        for i, t in enumerate(items, 1):
            print(f"{i:<5}{t.date:<13}{t.transaction_type:<10}{t.category:<16}"
                  f"{CURRENCY}{t.amount:>9.2f}  {t.description}")

    def totals(self, items=None):
        items = self.transactions if items is None else items
        income = sum(t.amount for t in items if t.transaction_type == "income")
        expense = sum(t.amount for t in items if t.transaction_type == "expense")
        return income, expense, income - expense

    def category_summary(self, items=None):
        items = self.transactions if items is None else items
        summary = {}
        for t in items:
            if t.transaction_type == "expense":
                summary[t.category] = summary.get(t.category, 0) + t.amount
        return summary

    def financial_summary(self):
        income, expense, balance = self.totals()
        print("\n--- Financial Summary ---")
        print(f"Total income : {CURRENCY}{income:.2f}")
        print(f"Total expense: {CURRENCY}{expense:.2f}")
        print(f"Balance      : {CURRENCY}{balance:.2f}")

        categories = self.category_summary()
        if categories:
            print("\nSpending by category:")
            for category, amount in sorted(categories.items(), key=lambda x: x[1], reverse=True):
                print(f"  {category:<18} {CURRENCY}{amount:.2f}")

        expenses = [t for t in self.transactions if t.transaction_type == "expense"]
        if expenses:
            largest = max(expenses, key=lambda t: t.amount)
            print(f"\nLargest expense: {CURRENCY}{largest.amount:.2f} - "
                  f"{largest.description} ({largest.category})")

    def search_filter(self):
        print("\n--- Search / Filter ---")
        keyword = input("Keyword (press Enter to skip): ").strip().lower()
        category = input("Category (press Enter to skip): ").strip().lower()
        t_type = input("Type income/expense (press Enter to skip): ").strip().lower()

        results = self.transactions
        if keyword:
            results = [t for t in results if keyword in
                       f"{t.description} {t.category} {t.payment_method}".lower()]
        if category:
            results = [t for t in results if t.category.lower() == category]
        if t_type in ("income", "expense"):
            results = [t for t in results if t.transaction_type == t_type]

        self.list_transactions(results)

    def set_budget(self):
        print("\n--- Set Monthly Budget ---")
        while True:
            try:
                amount = float(input("Monthly expense budget: ₹").strip())
                if amount >= 0:
                    self.monthly_budget = amount
                    self.save_data()
                    print(f"Budget set to {CURRENCY}{amount:.2f}")
                    return
                print("Budget cannot be negative.")
            except ValueError:
                print("Enter a valid number.")

    def budget_status(self):
        _, expense, _ = self.totals()
        print("\n--- Budget Status ---")
        print(f"Budget         : {CURRENCY}{self.monthly_budget:.2f}")
        print(f"Spent          : {CURRENCY}{expense:.2f}")
        print(f"Remaining      : {CURRENCY}{self.monthly_budget - expense:.2f}")
        if self.monthly_budget == 0:
            print("Set a budget to get a meaningful budget status.")
        elif expense > self.monthly_budget:
            print("Status         : OVER BUDGET")
        else:
            print("Status         : WITHIN BUDGET")

    def monthly_report(self):
        month = input("Enter month (YYYY-MM): ").strip()
        try:
            datetime.strptime(month, "%Y-%m")
        except ValueError:
            print("Invalid month. Use YYYY-MM.")
            return

        items = [t for t in self.transactions if t.date.startswith(month)]
        income, expense, balance = self.totals(items)
        print(f"\n--- Report for {month} ---")
        print(f"Income : {CURRENCY}{income:.2f}")
        print(f"Expense: {CURRENCY}{expense:.2f}")
        print(f"Balance: {CURRENCY}{balance:.2f}")

        categories = self.category_summary(items)
        if categories:
            print("\nCategory breakdown:")
            for category, amount in sorted(categories.items(), key=lambda x: x[1], reverse=True):
                print(f"  {category:<18} {CURRENCY}{amount:.2f}")
        else:
            print("No expense records for this month.")

    def run(self):
        while True:
            print("\n" + "=" * 52)
            print("              FINTRACK PY")
            print(" Personal Expense Intelligence & Budget System")
            print("=" * 52)
            print("1. Add Transaction")
            print("2. View Transactions")
            print("3. Search / Filter Transactions")
            print("4. Financial Summary")
            print("5. Set Monthly Budget")
            print("6. Check Budget Status")
            print("7. Monthly Report")
            print("8. Save Data")
            print("9. Exit")

            choice = input("\nEnter choice: ").strip()
            if choice == "1":
                self.add_transaction()
            elif choice == "2":
                self.list_transactions()
            elif choice == "3":
                self.search_filter()
            elif choice == "4":
                self.financial_summary()
            elif choice == "5":
                self.set_budget()
            elif choice == "6":
                self.budget_status()
            elif choice == "7":
                self.monthly_report()
            elif choice == "8":
                self.save_data()
                print("Data saved.")
            elif choice == "9":
                self.save_data()
                print("Thank you for using FINTRACK PY.")
                break
            else:
                print("Invalid choice. Please select 1-9.")


if __name__ == "__main__":
    FinTrack().run()
