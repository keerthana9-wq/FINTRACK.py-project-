import tempfile
from pathlib import Path
import json
import main

def test_transaction_roundtrip():
    t = main.Transaction("expense", 250, "Food", "2026-09-01", "Lunch", "UPI")
    d = t.to_dict()
    t2 = main.Transaction.from_dict(d)
    assert t2.amount == 250
    assert t2.category == "Food"

def test_date_validation():
    assert main.FinTrack.valid_date("2026-09-22")
    assert not main.FinTrack.valid_date("22-09-2026")

def test_totals():
    app = main.FinTrack()
    app.transactions = [
        main.Transaction("income", 20000, "Salary", "2026-09-01", "Income", "Bank"),
        main.Transaction("expense", 3000, "Food", "2026-09-02", "Food", "UPI"),
    ]
    income, expense, balance = app.totals()
    assert income == 20000
    assert expense == 3000
    assert balance == 17000

if __name__ == "__main__":
    test_transaction_roundtrip()
    test_date_validation()
    test_totals()
    print("All FINTRACK PY tests passed.")
