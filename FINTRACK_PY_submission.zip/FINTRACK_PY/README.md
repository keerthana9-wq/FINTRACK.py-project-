# FINTRACK PY
### Personal Expense Intelligence & Budget Management System

A beginner-to-intermediate Python CLI application for recording income and expenses, analyzing spending, setting a monthly budget, and generating reports.

## Features
- Add income/expense transactions
- Store amount, category, date, description and payment method
- View all transactions
- Search and filter transactions
- Calculate income, expenses and balance
- Show spending by category
- Identify the largest expense
- Set and check a monthly budget
- Generate a month-wise report
- Save/reload data using JSON
- Input validation and exception handling
- OOP with `Transaction` and `FinTrack` classes

## Technologies
- Python 3
- JSON
- Object-Oriented Programming
- File handling
- Exception handling

## How to Run
1. Install Python 3.
2. Open this folder in VS Code.
3. Open the terminal.
4. Run:
   `python main.py`
5. Follow the menu.

`data.json` is created automatically after saving/adding data.

## Suggested Demo Flow
1. Add an income of ₹20,000.
2. Add Food, Travel, Education and Shopping expenses.
3. View transactions.
4. Set a monthly budget.
5. Open Financial Summary.
6. Open Budget Status.
7. Generate a monthly report.

## Submission Checklist
- `main.py` — source code
- `README.md` — documentation
- `data.json` — sample saved data
- `screenshots/` — demonstration evidence
- `PROJECT_REPORT.md` — report content
