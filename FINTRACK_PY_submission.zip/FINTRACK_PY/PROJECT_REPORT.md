# FINTRACK PY — Project Report

## 1. Project Title
**FINTRACK PY — Personal Expense Intelligence & Budget Management System**

## 2. Problem Statement
Managing personal expenses becomes difficult when transactions are spread across different dates, categories and payment methods. FINTRACK PY provides one Python application to record transactions, summarize finances, analyze spending and monitor a budget.

## 3. Objective
To build a working Python application that can record income and expenses, categorize transactions, search/filter records, calculate financial summaries, identify spending patterns, set a monthly budget, check budget status, generate a report, and save/reload data.

## 4. Features
- Add transaction
- View transaction list
- Search and filter transactions
- Financial summary
- Spending-by-category analysis
- Largest expense detection
- Monthly budget
- Budget status
- Monthly report
- JSON data persistence
- Input validation and exception handling

## 5. Technologies
- Python 3
- JSON
- Object-Oriented Programming
- File handling
- Exception handling
- Lists and dictionaries
- Functions and loops

## 6. Application Architecture
`User → Menu → FinTrack methods → Transaction objects → JSON file`

The `Transaction` class represents individual transactions. The `FinTrack` class manages transactions, calculations, searching, budgeting and persistence.

## 7. Key Python Concepts Used
Variables, strings, numbers, lists, dictionaries, conditions, loops, functions, modules, file handling, JSON, exception handling, classes/OOP, list comprehensions and reusable functions.

## 8. Testing
The application was tested using:
1. Income and expense entry
2. Invalid transaction type
3. Invalid amount
4. Invalid date format
5. Transaction listing
6. Search/filter
7. Financial summary
8. Budget status
9. Monthly report
10. JSON save/reload

## 9. Demonstration Evidence
The `screenshots` folder contains sample evidence for:
1. Main menu
2. Adding a transaction
3. Transaction list
4. Financial summary
5. Budget/report output

## 10. Challenges and Solutions
**Challenge:** Keeping data after the program closes.  
**Solution:** JSON file storage with `save_data()` and `load_data()`.

**Challenge:** Invalid user input.  
**Solution:** Validation loops and exception handling.

**Challenge:** Organizing the application.  
**Solution:** OOP using `Transaction` and `FinTrack` classes.

## 11. Future Improvements
- GUI using Tkinter
- Charts for spending patterns
- Login/user profiles
- Export reports to CSV/PDF
- Database support using SQLite
- More advanced monthly analytics

## 12. Conclusion
FINTRACK PY combines Python fundamentals and intermediate concepts into one practical expense-management application. It demonstrates reusable functions, OOP, JSON persistence, validation, reporting and basic financial analysis.
